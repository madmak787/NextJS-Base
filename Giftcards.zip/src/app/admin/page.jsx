'use client'
import React from "react";
import { LoginForm } from "@/components/login-form"
import Image from "next/image";

export default function Page() {
  return (
    <div className="flex min-h-svh w-full items-center justify-center p-6 md:p-10">
      <div className="w-full max-w-sm">
        <Image src="/logo.png" alt="Logo" width={200} height={200} className="mx-auto mb-10" />
        <LoginForm className={''} />
      </div>
    </div>
  )
}
